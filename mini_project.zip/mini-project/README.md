# ShopSphere — Mini E-commerce App

A responsive React mini-store built with **React Router DOM** and **Redux Toolkit**. The cart is stored globally in Redux and persisted in `localStorage`.

## Features

- Home, Products, Cart, About, Checkout and 404 pages
- React Router navigation with active-link highlighting
- 8 sample products with images, prices and categories
- Add to cart confirmation toast
- Redux Toolkit `cartSlice` with `addToCart`, `removeFromCart`, `increaseQuantity`, `decreaseQuantity` and `clearCart`
- Cart item count in the navigation bar
- Quantity controls, remove action, empty-cart state and total price
- Product search and category filter
- Persistent cart using `localStorage`
- Checkout summary and order confirmation using `useNavigate()`
- Responsive layout for desktop, tablet and mobile

## Requirements

- Node.js 18 or newer
- npm (included with Node.js)

## Run locally

1. Extract `shop-sphere.zip`.
2. Open the extracted `shop-sphere` folder in VS Code (or another code editor).
3. Open a terminal in that folder.
4. Install dependencies:

   ```bash
   npm install
   ```

5. Start the development server:

   ```bash
   npm run dev
   ```

6. Open the local URL printed in the terminal (usually `http://localhost:5173`).

## Create a production build

```bash
npm run build
npm run preview
```

## Project structure

```text
shop-sphere/
├── public/
│   └── favicon.svg
├── src/
│   ├── app/
│   │   └── store.js
│   ├── components/
│   │   ├── Footer.jsx
│   │   ├── Navbar.jsx
│   │   ├── ProductCard.jsx
│   │   └── Toast.jsx
│   ├── data/
│   │   └── products.js
│   ├── features/
│   │   └── cart/
│   │       └── cartSlice.js
│   ├── pages/
│   │   ├── About.jsx
│   │   ├── Cart.jsx
│   │   ├── Checkout.jsx
│   │   ├── Home.jsx
│   │   ├── NotFound.jsx
│   │   └── Products.jsx
│   ├── App.jsx
│   ├── index.css
│   └── main.jsx
├── index.html
├── package.json
└── vite.config.js
```

## Notes

- Product photos are loaded from Unsplash, so an internet connection is needed to display them.
- This is a front-end learning project. Checkout displays a demo order confirmation; it does not process real payments or store customer information.
- Cart persistence is handled in the Redux slice using the browser's `localStorage`.
