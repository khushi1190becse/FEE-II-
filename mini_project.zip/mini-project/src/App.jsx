import { useState } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Toast from './components/Toast'
import Home from './pages/Home'
import Products from './pages/Products'
import Cart from './pages/Cart'
import About from './pages/About'
import Checkout from './pages/Checkout'
import NotFound from './pages/NotFound'

export default function App() {
  const [toast, setToast] = useState('')
  const location = useLocation()
  const showToast = (message) => {
    setToast(message)
    window.clearTimeout(window.__shopToastTimer)
    window.__shopToastTimer = window.setTimeout(() => setToast(''), 2600)
  }

  return <div className="app-shell">
    <Navbar />
    <Toast message={toast} />
    <Routes location={location}>
      <Route path="/" element={<Home onAdded={showToast} />} />
      <Route path="/products" element={<Products onAdded={showToast} />} />
      <Route path="/cart" element={<Cart />} />
      <Route path="/about" element={<About />} />
      <Route path="/checkout" element={<Checkout />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
    <Footer />
  </div>
}
