import { Link } from 'react-router-dom'
import { ArrowRight, ArrowUpRight, Leaf, PackageCheck, Heart } from 'lucide-react'
import { products } from '../data/products'
import ProductCard from '../components/ProductCard'

export default function Home({ onAdded }) {
  return (
    <main>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow"><span className="eyebrow-line" /> THE EVERYDAY EDIT</span>
          <h1>Find joy in the <em>little</em> things.</h1>
          <p>Considered pieces for your home, your rituals, and all the in-between moments. A little more lovely, every day.</p>
          <div className="hero-actions"><Link to="/products" className="btn btn-dark">Explore the shop <ArrowRight size={17} /></Link><Link to="/about" className="under-link">Our story <ArrowUpRight size={15} /></Link></div>
          <div className="hero-footnote"><span>01 / 03</span><span className="footnote-rule" /><span>CURATED FOR REAL LIFE</span></div>
        </div>
        <div className="hero-visual">
          <img src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1400&q=90" alt="Warm, thoughtfully styled living room" />
          <div className="hero-sticker"><span>LIVE</span><span>WELL</span><span>★</span></div>
          <div className="image-caption">THE ART OF SLOW LIVING <span>—</span> VOL. 01</div>
        </div>
      </section>

      <section className="benefits">
        <div><Leaf size={20} /><span>Thoughtfully selected</span></div><div><PackageCheck size={20} /><span>Easy, happy delivery</span></div><div><Heart size={20} /><span>Made to be loved</span></div>
      </section>

      <section className="section featured-section">
        <div className="section-heading"><div><span className="eyebrow">A FEW GOOD THINGS</span><h2>Small things. <em>Big feeling.</em></h2></div><Link to="/products" className="under-link">View all products <ArrowUpRight size={15} /></Link></div>
        <div className="product-grid">{products.slice(0, 4).map((product) => <ProductCard key={product.id} product={product} onAdded={onAdded} />)}</div>
      </section>
      <section className="quote-band"><span className="quote-mark">“</span><p>Make room for the things that make<br /> ordinary days feel extraordinary.</p><span className="quote-credit">THE SHOPSPHERE WAY</span></section>
      <section className="newsletter"><div><span className="eyebrow">A NOTE FROM US</span><h2>Good things are <em>on the way.</em></h2><p>Explore a collection made for living a little more intentionally.</p></div><Link to="/products" className="btn btn-light">Find your something <ArrowRight size={17} /></Link></section>
    </main>
  )
}
