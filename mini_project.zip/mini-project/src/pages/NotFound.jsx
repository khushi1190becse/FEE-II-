import { Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'

export default function NotFound() {
  return <main className="page-wrap"><section className="empty-cart"><span className="eyebrow">404 / PAGE NOT FOUND</span><h1>Looks like this page <em>moved on.</em></h1><p>The page you’re looking for doesn’t live here. Let’s get you back to something good.</p><Link to="/" className="btn btn-dark"><ArrowLeft size={17} /> Back home</Link></section></main>
}
