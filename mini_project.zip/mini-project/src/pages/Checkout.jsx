import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { ArrowRight, CheckCircle2 } from 'lucide-react'
import { clearCart, selectCartItems, selectCartTotal } from '../features/cart/cartSlice'

export default function Checkout() {
  const items = useSelector(selectCartItems)
  const total = useSelector(selectCartTotal)
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const [placed, setPlaced] = useState(false)

  const placeOrder = (event) => {
    event.preventDefault()
    dispatch(clearCart())
    setPlaced(true)
  }

  if (!items.length && !placed) return <main className="page-wrap"><section className="empty-cart"><span className="eyebrow">CHECKOUT</span><h1>Your bag is <em>empty.</em></h1><p>Add a few things before checking out.</p><Link to="/products" className="btn btn-dark">Browse products <ArrowRight size={17} /></Link></section></main>

  if (placed) return <main className="page-wrap"><section className="empty-cart success-state"><div className="success-icon"><CheckCircle2 size={34} /></div><span className="eyebrow">ORDER CONFIRMED</span><h1>Thank you for <em>your order.</em></h1><p>This is a demo checkout. Your order has been placed successfully in this sample experience.</p><button className="btn btn-dark" onClick={() => navigate('/products')}>Back to the shop <ArrowRight size={17} /></button></section></main>

  return <main className="page-wrap"><section className="page-intro"><span className="eyebrow">ONE LAST STEP</span><h1>Make it <em>yours.</em></h1><p>Complete the demo checkout to see your order confirmation.</p></section><section className="checkout-layout"><form className="checkout-form" onSubmit={placeOrder}><h2>Delivery details</h2><label>Full name<input required placeholder="Your name" /></label><label>Email address<input type="email" required placeholder="you@example.com" /></label><label>Delivery address<textarea required rows="3" placeholder="Street, city, postal code" /></label><button className="btn btn-dark" type="submit">Place demo order <ArrowRight size={17} /></button></form><aside className="order-card"><span className="eyebrow">YOUR ORDER</span><h2>Order <em>summary.</em></h2>{items.map((item) => <div className="checkout-item" key={item.id}><span>{item.name} <small>× {item.quantity}</small></span><strong>${(item.price * item.quantity).toFixed(2)}</strong></div>)}<div className="summary-line total-line"><span>Total</span><strong>${total.toFixed(2)}</strong></div><p className="tax-note">Demo only — no payment will be taken.</p></aside></section></main>
}
