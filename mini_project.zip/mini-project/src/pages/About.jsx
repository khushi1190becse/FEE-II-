import { Link } from 'react-router-dom'
import { ArrowRight, Heart, Leaf, Sparkles } from 'lucide-react'

export default function About() {
  return <main className="page-wrap">
    <section className="about-hero"><div><span className="eyebrow">A LITTLE ABOUT US</span><h1>Less, but <em>lovelier.</em></h1><p>We believe the things we live with should earn their place — not just by how they look, but by how they make everyday life feel.</p><Link to="/" className="btn btn-dark">Back to home <ArrowRight size={17} /></Link></div><img src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=90" alt="Calm, sunlit home interior" /></section>
    <section className="about-values"><div><Leaf /><span>01 / THOUGHTFUL</span><h3>Choose with care.</h3><p>We look for useful pieces, considered details and lasting appeal.</p></div><div><Heart /><span>02 / HUMAN</span><h3>Made for real life.</h3><p>Good design should feel welcoming, practical and easy to enjoy.</p></div><div><Sparkles /><span>03 / JOYFUL</span><h3>Find the little magic.</h3><p>Everyday rituals deserve objects that bring a little delight.</p></div></section>
    <section className="about-bottom"><span className="eyebrow">COME ON IN</span><h2>Your everyday, <em>elevated.</em></h2><Link to="/products" className="under-link">Explore the collection <ArrowRight size={16} /></Link></section>
  </main>
}
