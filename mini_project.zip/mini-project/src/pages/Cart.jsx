import { Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { ArrowRight, Minus, Plus, Trash2, ShoppingBag } from 'lucide-react'
import { decreaseQuantity, increaseQuantity, removeFromCart, selectCartItems, selectCartTotal, clearCart } from '../features/cart/cartSlice'

const money = (amount) => `$${amount.toFixed(2)}`

export default function Cart() {
  const items = useSelector(selectCartItems)
  const total = useSelector(selectCartTotal)
  const dispatch = useDispatch()

  if (!items.length) return <main className="page-wrap"><section className="empty-cart"><div className="empty-icon"><ShoppingBag size={28} /></div><span className="eyebrow">YOUR BAG</span><h1>A little room for <em>something good.</em></h1><p>Your bag is waiting for a few lovely things.</p><Link to="/products" className="btn btn-dark">Explore the shop <ArrowRight size={17} /></Link></section></main>

  return (
    <main className="page-wrap">
      <section className="page-intro cart-intro"><span className="eyebrow">YOUR BAG / {items.reduce((sum, item) => sum + item.quantity, 0)} ITEMS</span><h1>Good choice. <em>Indeed.</em></h1><p>Everything you picked, all in one happy place.</p></section>
      <section className="cart-layout">
        <div className="cart-items">
          <div className="cart-table-head"><span>PRODUCT</span><span>QUANTITY</span><span>SUBTOTAL</span></div>
          {items.map((item) => <article className="cart-row" key={item.id}>
            <div className="cart-product"><img src={item.image} alt={item.name} /><div><span>{item.category}</span><h3>{item.name}</h3><p>{money(item.price)}</p><button className="remove-button" onClick={() => dispatch(removeFromCart(item.id))}><Trash2 size={13} /> Remove</button></div></div>
            <div className="quantity-control"><button onClick={() => dispatch(decreaseQuantity(item.id))} aria-label={`Decrease ${item.name} quantity`}><Minus size={13} /></button><span>{item.quantity}</span><button onClick={() => dispatch(increaseQuantity(item.id))} aria-label={`Increase ${item.name} quantity`}><Plus size={13} /></button></div>
            <strong className="line-total">{money(item.price * item.quantity)}</strong>
          </article>)}
          <button className="clear-cart" onClick={() => dispatch(clearCart())}>Clear bag</button>
        </div>
        <aside className="order-card"><span className="eyebrow">THE TOTAL</span><h2>Order <em>summary.</em></h2><div className="summary-line"><span>Subtotal</span><strong>{money(total)}</strong></div><div className="summary-line"><span>Delivery</span><strong className="free">Complimentary</strong></div><div className="summary-line total-line"><span>Total</span><strong>{money(total)}</strong></div><p className="tax-note">Taxes included where applicable.</p><Link to="/checkout" className="btn btn-dark checkout-btn">Continue to checkout <ArrowRight size={17} /></Link><Link to="/products" className="continue-link">Continue shopping</Link></aside>
      </section>
    </main>
  )
}
