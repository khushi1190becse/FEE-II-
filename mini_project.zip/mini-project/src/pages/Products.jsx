import { useMemo, useState } from 'react'
import { Search, SlidersHorizontal } from 'lucide-react'
import { products } from '../data/products'
import ProductCard from '../components/ProductCard'

export default function Products({ onAdded }) {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')
  const categories = ['All', ...new Set(products.map((product) => product.category))]
  const filtered = useMemo(() => products.filter((product) => {
    const matchesSearch = `${product.name} ${product.description}`.toLowerCase().includes(search.toLowerCase())
    return matchesSearch && (category === 'All' || product.category === category)
  }), [search, category])

  return (
    <main className="page-wrap">
      <section className="page-intro products-intro"><span className="eyebrow">THE SHOP / 2026 COLLECTION</span><h1>Good things, <em>gathered.</em></h1><p>Useful, beautiful, and a little bit unexpected. Find your new everyday favourite.</p></section>
      <section className="catalogue">
        <div className="catalogue-top"><span>{filtered.length} thoughtfully chosen pieces</span><div className="search-box"><Search size={17} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search the collection..." aria-label="Search products" /></div></div>
        <div className="catalogue-body">
          <aside className="filters"><div className="filter-title"><SlidersHorizontal size={16} /> FILTER BY</div>{categories.map((item) => <button key={item} className={`filter-option${category === item ? ' selected' : ''}`} onClick={() => setCategory(item)}>{item}<span>{item === 'All' ? products.length : products.filter((p) => p.category === item).length}</span></button>)}</aside>
          <div className="catalogue-results">{filtered.length ? <div className="product-grid">{filtered.map((product) => <ProductCard key={product.id} product={product} onAdded={onAdded} />)}</div> : <div className="no-results"><h3>No finds just yet.</h3><p>Try another search or category.</p><button className="under-link" onClick={() => { setSearch(''); setCategory('All') }}>Clear filters</button></div>}</div>
        </div>
      </section>
    </main>
  )
}
