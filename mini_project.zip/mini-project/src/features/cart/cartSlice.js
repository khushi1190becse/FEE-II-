import { createSlice } from '@reduxjs/toolkit'

const loadCart = () => {
  try {
    const savedCart = localStorage.getItem('shopsphere-cart')
    return savedCart ? JSON.parse(savedCart) : []
  } catch {
    return []
  }
}

const initialState = {
  items: loadCart(),
}

const saveCart = (items) => {
  try {
    localStorage.setItem('shopsphere-cart', JSON.stringify(items))
  } catch {
    // The app still works for the current session if storage is unavailable.
  }
}

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const existing = state.items.find((item) => item.id === action.payload.id)
      if (existing) existing.quantity += 1
      else state.items.push({ ...action.payload, quantity: 1 })
      saveCart(state.items)
    },
    removeFromCart: (state, action) => {
      state.items = state.items.filter((item) => item.id !== action.payload)
      saveCart(state.items)
    },
    increaseQuantity: (state, action) => {
      const item = state.items.find((product) => product.id === action.payload)
      if (item) item.quantity += 1
      saveCart(state.items)
    },
    decreaseQuantity: (state, action) => {
      const item = state.items.find((product) => product.id === action.payload)
      if (item) {
        item.quantity -= 1
        if (item.quantity <= 0) {
          state.items = state.items.filter((product) => product.id !== action.payload)
        }
      }
      saveCart(state.items)
    },
    clearCart: (state) => {
      state.items = []
      saveCart(state.items)
    },
  },
})

export const { addToCart, removeFromCart, increaseQuantity, decreaseQuantity, clearCart } = cartSlice.actions
export const selectCartItems = (state) => state.cart.items
export const selectCartCount = (state) => state.cart.items.reduce((sum, item) => sum + item.quantity, 0)
export const selectCartTotal = (state) => state.cart.items.reduce((sum, item) => sum + item.price * item.quantity, 0)

export default cartSlice.reducer
