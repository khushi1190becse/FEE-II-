import { useDispatch } from 'react-redux'
import { ShoppingBag, ArrowUpRight } from 'lucide-react'
import { addToCart } from '../features/cart/cartSlice'

export default function ProductCard({ product, onAdded }) {
  const dispatch = useDispatch()
  const handleAdd = () => {
    dispatch(addToCart(product))
    onAdded(`${product.name} added to your bag`)
  }

  return (
    <article className="product-card">
      <div className="product-image-wrap">
        <img src={product.image} alt={product.name} className="product-image" loading="lazy" />
        {product.tag && <span className="product-tag">{product.tag}</span>}
        <button className="quick-add" onClick={handleAdd} aria-label={`Add ${product.name} to cart`}><ShoppingBag size={17} /></button>
      </div>
      <div className="product-meta"><span>{product.category}</span><span>${product.price.toFixed(2)}</span></div>
      <h3>{product.name}</h3>
      <p>{product.description}</p>
      <button className="text-add" onClick={handleAdd}>Add to bag <ArrowUpRight size={15} /></button>
    </article>
  )
}
