import { Link } from 'react-router-dom'
import { ArrowUpRight } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-main">
        <div>
          <Link to="/" className="brand footer-brand"><span className="brand-mark">s.</span><span>shopsphere<span className="brand-period">.</span></span></Link>
          <p>Thoughtful finds for everyday living.</p>
        </div>
        <div className="footer-note"><span>GOOD THINGS, EVERY DAY.</span><p>Made for the moments that make a home.</p></div>
      </div>
      <div className="footer-bottom"><span>© {new Date().getFullYear()} ShopSphere. Demo store project.</span><Link to="/products">Explore the collection <ArrowUpRight size={14} /></Link></div>
    </footer>
  )
}
