import { NavLink, Link } from 'react-router-dom'
import { ShoppingBag, ArrowUpRight } from 'lucide-react'
import { useSelector } from 'react-redux'
import { selectCartCount } from '../features/cart/cartSlice'

export default function Navbar() {
  const count = useSelector(selectCartCount)
  const linkClass = ({ isActive }) => `nav-link${isActive ? ' active' : ''}`

  return (
    <header className="site-header">
      <div className="nav-shell">
        <Link to="/" className="brand" aria-label="ShopSphere home">
          <span className="brand-mark">s.</span>
          <span>shopsphere<span className="brand-period">.</span></span>
        </Link>
        <nav className="main-nav" aria-label="Main navigation">
          <NavLink to="/" end className={linkClass}>Home</NavLink>
          <NavLink to="/products" className={linkClass}>Shop</NavLink>
          <NavLink to="/about" className={linkClass}>Our story</NavLink>
        </nav>
        <Link to="/cart" className="cart-link" aria-label={`Shopping bag, ${count} items`}>
          <ShoppingBag size={19} strokeWidth={1.8} />
          <span>Bag</span>
          <span className="cart-count">{count}</span>
        </Link>
      </div>
    </header>
  )
}
